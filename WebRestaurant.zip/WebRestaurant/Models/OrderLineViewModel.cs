using BusinessRestaurant;

namespace WebRestaurant.Models;

public class OrderLineViewModel {
    public static OrderLine OrderLineDetail {get; set;} = new OrderLine();
}